# 🩺 Medical Record & Appointment Management System

A lightweight Flask web app for managing patients and scheduling appointments.

## 🚀 Features
- Add and view patient details
- Schedule and view upcoming appointments
- Beautiful UI with background themes
- Uses MySQL as backend

## 💻 Tech Stack
- Python (Flask)
- HTML/CSS
- MySQL
- dotenv for configuration

## ⚙️ Setup

```bash
git clone https://github.com/yourusername/medical_app.git
cd medical_app
pip install -r requirements.txt
```

Configure your `.env` file with MySQL details.

## 🗄 Database Schema

- **patients**
  - `patient_id` (INT, PK)
  - `name`, `age`, `gender`, `diagnosis`, `address`, `medicines`, `medical_history`

- **appointments**
  - `appointment_id` (INT, PK)
  - `patient_id` (FK), `appointment_date`, `appointment_time`, `reason`, `status`

## 🤝 Contributions
Feel free to fork the repo, open issues, and submit pull requests!